#ifndef HW3_P2_H
#define HW3_P2_H

#include <stdlib.h>
#include "stack.h"

void empty(StackInfo* stack);

#endif
