#ifndef STACK_H
#define STACK_H

typedef struct StackNode {
    struct StackNode* next; // pointer to item in the stack ("below" the current node)
    void* stackValue;       // pointer to the data stored
} StackNode;

typedef struct{
    StackNode* head;    // pointer to the head of the stack, NULL if empty
    int depth;          // current height of the stack, 0 if empty
} StackInfo;

void* newNode(void** data);
int isEmpty(StackInfo* stack);
void push(StackInfo* stack, void* data);
void* pop(StackInfo* stack);
void* peek(StackInfo* stack);
void empty(StackInfo* stack);
#endif /* STACK_H */
