#ifndef HELPERS_2_H
#define HELPERS_2_H
#include <stdlib.h>
int get_index(char* str);
char* get_first_char(char* str);

#endif
