// Define any helper functions here
#include <stdlib.h>
char* get_first_char(char* str)
{
    char* newone = (char*)malloc(200 * sizeof(char));
    int check_str = 0;
    int count = 0;
    int check_space = 0;
    while(*str != '\0')
    {
        if((check_str == 0 && *str != ' ')&&(check_str == 0 && *str != '\n')&&(check_str == 0 && *str != '\t'))
        {
            check_space = 1;
            *newone = *str;
            newone ++;
            count ++;
            check_str = 1;
        }
        if((check_str == 1 && *str != ' ')&&(check_str == 1 && *str != '\n')&&(check_str == 1 && *str != '\t'))
        {
            check_space = 1;
            *newone = *str;
            newone ++;
            count ++;
        }
        if((check_str == 1 && *str == ' ')||(check_str == 1 && *str == '\n')||(check_str == 1 && *str == '\t'))
        {
            *newone = '\0';
            for (int aa = 0; aa < count - 1; aa ++)
            {
                newone --;
            }
            return newone;
        }
        str++;
    }
    for (int aa = 0; aa < count - 1; aa ++)
    {
        newone --;
    }
    if(check_space == 0)
    {
        return NULL;
    }
    return newone;
}
int get_index(char* str)
{
    int check_str = 0;
    int index = 0;
    while(*str != '\0')
    {
        if((*str != ' ' && check_str == 0) &&(*str != '\t' && check_str == 0) && (*str != '\n' && check_str == 0))
        {
            check_str = 1;
            str++;
            index ++;
            continue;
        }
        if((check_str != 0 && *str == ' ')||(check_str != 0 && *str == '\t')||(check_str != 0 && *str == '\n'))
        {
            check_str = 2;
            str++;
            index ++;
            continue;
        }
        if((check_str == 2 && *str != ' ')&&(check_str == 2 && *str != '\t') && (check_str == 2 && *str != '\n'))
        {
            return index;
        }
        str++;
        index ++;
    }
    return index;
}
