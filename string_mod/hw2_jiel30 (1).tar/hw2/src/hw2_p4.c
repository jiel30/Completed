#include <errno.h>
#include "hw2_p4.h"
#include "stack.h"
#include "hw2_p3.h"

Token* performOp(Token* op, Token* value1, Token* value2) {
    Token* result = (Token*)malloc(sizeof(Token));
    if((*((char*)(op->datavalue)) == '%' || *((char*)(op->datavalue)) == '^')&&( value2->type != INTEGER || value1->type != INTEGER))
    {
        errno = TYPERR;
        return NULL;
    }
    if(*((char*)(op->datavalue)) == '/' && *(int*)(value2-> datavalue) == 0)
    {
        errno = TYPERR;
        return NULL;
    }
    if(value1 -> type ==  value2 -> type )
    {
        result -> type = value2 -> type;
    }
    else
    {
        result -> type = FLOAT;
    }
        
    if(result -> type == FLOAT)
    {
        if(*((char*)(op->datavalue)) == '+')
        {
//            printf("value1: %f  value2: %f\n",(float*)(value1->datavalue),(float*)(value2->datavalue));
            float r;
//            printf("get in float +\n");
            if(value1 -> type == INTEGER&&value2-> type == INTEGER)
            {
                r = *(int*)(value1-> datavalue) + *(int*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == INTEGER)
            {
                r = *(float*)(value1-> datavalue) + *(int*)(value2-> datavalue);
            }
            if(value1 -> type == INTEGER&&value2-> type == FLOAT)
            {
                r = *(int*)(value1-> datavalue) + *(float*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == FLOAT)
            {
                r = *(float*)(value1-> datavalue) + *(float*)(value2-> datavalue);
            }
            float* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '-')
        {
            float r;
            if(value1 -> type == INTEGER&&value2-> type == INTEGER)
            {
                r = *(int*)(value1-> datavalue) - *(int*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == INTEGER)
            {
                r = *(float*)(value1-> datavalue) - *(int*)(value2-> datavalue);
            }
            if(value1 -> type == INTEGER&&value2-> type == FLOAT)
            {
                r = *(int*)(value1-> datavalue) - *(float*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == FLOAT)
            {
                r = *(float*)(value1-> datavalue) - *(float*)(value2-> datavalue);
            }
            float* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '*')
        {
//            printf("f1: %f\tf2: %f\n",(float)v1,(float)v2);
            float r;
            if(value1 -> type == INTEGER&&value2-> type == INTEGER)
            {
                r = *(int*)(value1-> datavalue) * *(int*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == INTEGER)
            {
                r = *(float*)(value1-> datavalue) * *(int*)(value2-> datavalue);
            }
            if(value1 -> type == INTEGER&&value2-> type == FLOAT)
            {
                r = *(int*)(value1-> datavalue) * *(float*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == FLOAT)
            {
                r = *(float*)(value1-> datavalue) * *(float*)(value2-> datavalue);
            }
//            printf("result for *: %f\n",r);
            float* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '^')
        {
            float r;
            if(value1 -> type == INTEGER&&value2-> type == INTEGER)
            {
                r = pow(*(int*)(value1-> datavalue), *(int*)(value2-> datavalue));
            }
            if(value1 -> type == FLOAT&&value2-> type == INTEGER)
            {
                r = pow(*(float*)(value1-> datavalue), *(int*)(value2-> datavalue));
            }
            if(value1 -> type == INTEGER&&value2-> type == FLOAT)
            {
                r = pow(*(int*)(value1-> datavalue), *(float*)(value2-> datavalue));
            }
            if(value1 -> type == FLOAT&&value2-> type == FLOAT)
            {
                r = pow(*(float*)(value1-> datavalue), *(float*)(value2-> datavalue));
            }
            float* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '/')
        {
            float r;
//            printf("get inyo /\n");
            if(value1 -> type == FLOAT&&value2-> type == INTEGER)
            {
                r = *(float*)(value1-> datavalue) / *(int*)(value2-> datavalue);
            }
            if(value1 -> type == INTEGER&&value2-> type == FLOAT)
            {
                r = *(int*)(value1-> datavalue) / *(float*)(value2-> datavalue);
            }
            if(value1 -> type == FLOAT&&value2-> type == FLOAT)
            {
                r = *(float*)(value1-> datavalue) / *(float*)(value2-> datavalue);
            }
//                        printf("result for /: %f\n",r);
            float* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
    }
    else
    {
        if(*((char*)(op->datavalue)) == '+')
        {
            int r;
            int v1 = *(int*)(value1-> datavalue);
            int v2 = *(int*)(value2-> datavalue);
//            printf("value1: %d\tvalue2: %d\n",v1,v2);
            r = v1+v2;
//            printf("result for +: %d\n",r);
            int* temp = (int*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '-')
        {
            int r;
            //            printf("result for +: %f\n",r);
            r = *(int*)(value1-> datavalue) - *(int*)(value2-> datavalue);
            int* temp = (int*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '*')
        {
            int r;
            //            printf("result for +: %f\n",r);
            r = *(int*)(value1-> datavalue) * *(int*)(value2-> datavalue);
            int* temp = (int*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '/')
        {
            int r;
            //            printf("result for +: %f\n",r);
            r = *(int*)(value1-> datavalue) / *(int*)(value2-> datavalue);
            int* temp = (int*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '%')
        {
            int r;
            //            printf("result for +: %f\n",r);
            r = *(int*)(value1-> datavalue) % *(int*)(value2-> datavalue);
            int* temp = (int*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
        if(*((char*)(op->datavalue)) == '^')
        {
            int r;
            r = pow(*(int*)(value1-> datavalue), *(int*)(value2-> datavalue));
            int* temp = (float*)malloc(sizeof(float));
            *temp = r;
            result -> datavalue = (void*)temp;
        }
    }
    if(result->type == INTEGER)
    {
        result -> datavalue = (int*)(result -> datavalue);
    }
    else
    {
        result -> datavalue = (float*)(result -> datavalue);
    }
//    printf("value1: %f\tvalue2: %d\n",*(float*)(value1-> datavalue),*(int*)(value2-> datavalue));
    free(op);
    free(value1);
    free(value2);
    return result;
}

Token* evaluatePostfix(char* exp) {
    StackInfo stack;
    Token* temp;
    int a = 0;
    while(get_first_char(exp) != NULL)
    {
        temp = tokenizeCalc(&exp);
        if(temp->type != SYMBOL)
        {
            push(&stack,temp);
            a++;
//            printf("pushed #1\ta: %d\n",a);
        }
        else
        {
            
            if(a == 0)
            {
                errno = ENOVAL;
//                printf("the first position\n");
                //                empty(&stack);
                return NULL;
            }
            Token *value2 = (Token*)pop(&stack);
            a --;
//            printf("poped #1\ta: %d\n",a);
            if(a == 0)
            {
                errno = ENOVAL;
//                printf("the second position\n");
                //                empty(&stack);
                return NULL;
            }
            Token* value1 = (Token*)pop(&stack);
            a --;
//            printf("poped #2\ta: %d\n",a);
//             Token* get = performOp(temp, value1, value2);
//             if(get == NULL)
//             {
//                 errno = ENOVAL;
//                 return NULL;
//             }
            push(&stack,performOp(temp, value1, value2));
            if(errno == TYPERR)
            {
                errno =ENOVAL;
                return NULL;
            }
            a ++;
//            printf("pushed #2\ta: %d\n",a);
        }
    }
    a--;
    if(a != 0)
    {
        errno = ENOOP;
        //                printf("the first position\n");
        //        empty(&stack);
        return NULL;
    }
    Token* result = pop(&stack);
//     if(result->type == INTEGER)
//     {
//         result -> datavalue = (int*)(result -> datavalue);
//     }
//     else
//     {
//         result -> datavalue = (float*)(result -> datavalue);
//     }
    return result;
}
