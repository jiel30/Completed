#include "stack.h"
#include "hw2_p3.h"

void empty(StackInfo* stack) {
    if(isEmpty(stack) == 1)
    {
        return;
    }
    while(stack -> head -> next != NULL)
    {
        StackNode *temp = stack -> head;
        stack -> head = temp -> next;
        stack -> depth --;
        free(temp);
    }
    StackNode *temp = stack -> head;
    stack -> head = NULL;
    stack -> depth = 0;
    free(temp);
}
