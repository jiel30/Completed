// Stack implementation via Linked list
#include <stdio.h> 
#include <stdlib.h>
#include <limits.h>
#include "stack.h"

// Functions to modify
void* newNode(void** data)
{
    StackNode* stackNode = (StackNode*)malloc(sizeof(StackNode));
    stackNode->stackValue = *data;
    stackNode->next = NULL;
    return stackNode;
}

int isEmpty(StackInfo* stack)
{
    if(stack -> depth == 0 && stack -> head == NULL)
    {
        return 1;
    }
    return 0;
}

void push(StackInfo* stack, void* data)
{
    if(stack == NULL)
    {
        return;
    }
    StackNode* stackNode = newNode(&data);
    stackNode->next = stack-> head;
    (*stack).depth ++;
    stack -> head = stackNode;
//    printf("%d pushed to stack\n", (int*)data);
}

void* pop(StackInfo* stack)
{
    if (stack -> head == NULL)
    {
        return NULL;
    }
    StackNode* temp = stack -> head;
    void* value = stack -> head -> stackValue;
    stack -> head = temp -> next;
    free(temp);
    (stack -> depth) --;
    return value;
    
}

void* peek(StackInfo* stack)
{
    if (isEmpty(stack) == 1)
        return NULL;
    return stack -> head ->stackValue;
} 

// void empty(StackInfo* stack)
// {
    
// }
