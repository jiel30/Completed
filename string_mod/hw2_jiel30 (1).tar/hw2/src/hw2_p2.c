#include "hw2_p1.h"
#include "hw2_p2.h"
#include "helpers2.h"
#include <stdlib.h>
int get_index(char* str);
char* get_first_char(char* str);
// Token* tokenizeCalc(char** str) {
//     Token* a = (Token*)malloc(sizeof(Token));
//     if (str == NULL)
//     {
//         errno =EINVAL;
//         return NULL;
//     }
//     char* first_one = get_first_char(*str);
//     if (first_one == NULL)
//     {
//         errno = EINVAL;
//         return NULL;
//     }
// //    printf("first_one: %c\n",*first_one);
//     if((*first_one == '+' ||*first_one == '-' ||*first_one == '*' ||*first_one == '/' ||*first_one == '%' ||*first_one == '^')&&(*(first_one+1) == '\0'))
//     {
// //        printf("get into symbol\n");
//         a->type = SYMBOL;
//         a->datavalue = first_one;
//     }
//     else
//     {
//         int f_i = 0;
//         float f_number = ics53atoi(first_one);
//         if(errno != 0)
//         {
//             f_i = 1;
//             f_number = ics53atof(first_one);
//             errno = 0;
//         }
//         if(errno != 0)
//         {
//             errno = EINVAL;
//             return NULL;
//         }
//         else
//         {
// //            printf("comparing: float_ver:%f vs int_ver:%d\n",f_number,(int)f_number);
//             if(f_i == 0)
//             {
// //                printf("same, integer\n");
//                 a -> type = INTEGER;
//                 int* temp = (int*)malloc(sizeof(int));
//                 *temp = (int)f_number;
// //                printf("int_number: %d\n",temp);
//                 a -> datavalue = temp;
// //                printf("a -> value: %f\n",*(float*)(a -> datavalue));
//             }
//             else
//             {
// //                printf("diff, float\n");
//                 a -> type = FLOAT;
//                 float* temp = (float*)malloc(sizeof(int));
//                 *temp = (float)f_number;
// //                printf("f_number: %f\n",temp);
//                 a -> datavalue = temp;
//             }
//         }
//     }
//     int index = get_index(*str);
// //    printf("index: %d\n",index);
// //    printf("for a: %d\n",a->type);
//     char* change = *str;
//     for (int aa = 0; aa < index; aa++)
//     {
//         change ++;
//     }
//     *str = change;
//     return a;
// }
Token* tokenizeCalc(char** str) {
    Token* a = (Token*)malloc(sizeof(Token));
    if (str == NULL)
    {
        errno =EINVAL;
        return NULL;
    }
    char* first_one = get_first_char(*str);
    if (first_one == NULL)
    {
        errno = EINVAL;
        return NULL;
    }
//    printf("first_one: %c\n",*first_one);
    if((*first_one == '+' ||*first_one == '-' ||*first_one == '*' ||*first_one == '/' ||*first_one == '%' ||*first_one == '^')&&(*(first_one+1) == '\0'))
    {
//        printf("get into symbol\n");
        a->type = SYMBOL;
        a->datavalue = first_one;
    }
    else
    {
        float f_number = ics53atof(first_one);
        if(errno != 0)
        {
            errno = EINVAL;
            return NULL;
        }
        else
        {
//            printf("comparing: float_ver:%f vs int_ver:%d\n",f_number,(int)f_number);
            if(f_number == (int)f_number)
            {
//                printf("same, integer\n");
                a -> type = INTEGER;
                int* temp = (int*)malloc(sizeof(int));
                *temp = (int)f_number;
//                printf("int_number: %d\n",temp);
                a -> datavalue = (void*)temp;
//                printf("a -> value: %f\n",*(float*)(a -> datavalue));
            }
            else
            {
//                printf("diff, float\n");
                a -> type = FLOAT;
                float* temp = (float*)malloc(sizeof(int));
                *temp = f_number;
//                printf("f_number: %f\n",temp);
                a -> datavalue = (void*)temp;
            }
        }
    }
    int index = get_index(*str);
//    printf("index: %d\n",index);
    char* change = *str;
    for (int aa = 0; aa < index; aa++)
    {
        change ++;
    }
    *str = change;
    return a;
}

// help functions

// char* get_first_char(char* str)
// {
//     char* newone = (char*)malloc(200 * sizeof(char));
//     int check_str = 0;
//     int count = 0;
//     while(*str != '\0')
//     {
//         if((check_str == 0 && *str != ' ')&&(check_str == 0 && *str != '\n')&&(check_str == 0 && *str != '\t'))
//         {
//             *newone = *str;
//             newone ++;
//             count ++;
//             check_str = 1;
//         }
//         if((check_str == 1 && *str != ' ')&&(check_str == 1 && *str != '\n')&&(check_str == 1 && *str != '\t'))
//         {
//             *newone = *str;
//             newone ++;
//             count ++;
//         }
//         if((check_str == 1 && *str == ' ')||(check_str == 1 && *str == '\n')||(check_str == 1 && *str == '\t'))
//         {
//             *newone = '\0';
//             for (int aa = 0; aa < count - 1; aa ++)
//             {
//                 newone --;
//             }
//             return newone;
//         }
//         str++;
//     }
//     for (int aa = 0; aa < count - 1; aa ++)
//     {
//         newone --;
//     }
//     return newone;
// }
// int get_index(char* str)
// {
//     int check_str = 0;
//     int index = 0;
//     while(*str != '\0')
//     {
//         if((*str != ' ' && check_str == 0) &&(*str != '\t' && check_str == 0) && (*str != '\n' && check_str == 0))
//         {
//             check_str = 1;
//             str++;
//             index ++;
//             continue;
//         }
//         if((check_str != 0 && *str == ' ')||(check_str != 0 && *str == '\t')||(check_str != 0 && *str == '\n'))
//         {
//             check_str = 2;
//             str++;
//             index ++;
//             continue;
//         }
//         if((check_str == 2 && *str != ' ')&&(check_str == 2 && *str != '\t') && (check_str == 2 && *str != '\n'))
//         {
//             return index;
//         }
//         str++;
//         index ++;
//     }
//     return index;
// }
