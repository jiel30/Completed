#include "helpers2.h"
#include "hw2_p1.h"

int contains(const char* str, const char c) {
    int count = 0;
    if(str == NULL || c == '\0')
    {
        return -1;
    }
    while(*str != '\0')
    {
        if(*str == c)
        {
            count ++;
        }
        str++;
    }
    return count;
}

char* prefix(const char* str, const char* tokens) {
    if(str == NULL || tokens == NULL)
    {
        return NULL;
    }
    while(*str != '\0')
    {
        if(contains(tokens,*str) != 0)
        {
            str ++;
        }
        else
        {
            return str;
        }
    }
    char* empty = "";
    return empty;
}

int ics53atoi(const char *str) {
    if(str == ""|| str == NULL)
    {
        errno = INTERR;
        return 0;
    }
    int minus = 0;
    char* integer = "122333444455555666666777777788888888999999999";
    int count = 0;
    int result = 0;
    while(*str != '\0')
    {
        count ++;
        str ++;
    }
    for (int aa = count; aa > 0; aa--)
    {
        str--;
    }
    count --;
    int length = count;
    while(*str != '\0')
    {
        if(count == length & *str == '-')
        {
            str++;
            count --;
            minus = 1;
            continue;
        }
        int number = contains(integer,*str);
        if(*str != '0' && number == 0)
        {
            errno = INTERR;
            return 0;
        }
        int size = 1;
        for (int aa = 0; aa < count; aa++)
        {
            size = size * 10;
        }
        result += size * number;
        str ++;
        count --;
    }
    if(minus == 1)
    {
        return -1 * result;
    }
    return result;
}

float ics53atof(const char *str) {
    if(str =="" || str == NULL)
    {
        errno = FLTERR;
        return 0;
    }
    int point_number = 0;
    int integer = -1;
    int decimal = 0;
    float result = 0;
    int minus = 0;
    int count = 0;
    char* i = "122333444455555666666777777788888888999999999";
    int time_dec = 1;
    while(*str != '\0')
    {
//        printf("start: %c\n",*str);
        int number = contains(i,*str);
        if(number == 0)
        {
            if(*str == '0')
            {
                if(point_number == 0)
                {
                    integer ++;
                }
                else
                {
                    decimal ++;
                }
                str++;
                count ++;
                continue;
            }
            if(count == 0 && *str == '-')
            {
                minus ++;
                str++;
                count ++;
                continue;
            }
            if(point_number == 0 && *str == '.')
            {
                point_number ++;
                str++;
                count ++;
                continue;
            }
//            printf("%c\n",*str);
            errno = FLTERR;
            return 0;
        }
        else
        {
            if(point_number == 0)
            {
                integer ++;
            }
            else
            {
                decimal ++;
            }
        }
        str ++;
        count ++;
    }
//    printf("count: %d\n",count);
    for (int aa = 0; aa < count; aa++)
    {
        str--;
    }
//    printf("point_number: %d   |   minus: %d\n",point_number,minus);
//    printf("integer: %d   |   decimal: %d\n",integer,decimal);
    while(*str != '\0')
    {
//        printf("str: %c\n",*str);
        if(*str == '-' || *str == '.')
        {
            str++;
            continue;
        }
        int number = contains(i, *str);
        float size = 1.0;
        if(integer >= 0)
        {
            for (int aa = 0; aa < integer; aa++)
            {
                size = size * 10;
            }
            integer --;
        }
        else
        {
            for (int aa = 0; aa < time_dec; aa++)
            {
                size = size * 0.1;
//                printf("temp: %f\n",size);
            }
            time_dec ++;
            decimal --;
        }
//        printf("temp: %f\n",size);
        result += number * size;
        str++;
    }
    if(minus != 0)
    {
        return -1 * result;
    }
    return result;
}

char** getSubstrings(char *str, int *size) {
    if(str == "" || str == NULL)
    {
        return NULL;
    }
    char **a = (char**)malloc(30 * sizeof(char*));
    int count = 0;
    int check_size = 0;
    int ct = 0;
    int check_p_size = 0;
    int size_number = 0;
    int only_space = 0;
    while(*str != '\0')
    {
        if(*str != ' '&&*str != '\n' && *str != '\t')
        {
            only_space = 1;
        }
        if(count == 0 && *str != ' '&& *str != '\n' && *str != '\t')
        {
            *a = str;
            size_number ++;
            ct++;
        }
        if(*str == ' ' || *str == '\n' || *str == '\t')
        {
            *str= '\0';
        }
        if((*str == '\0' && *(str + 1) != ' ' && *(str + 1) != '\0' && *(str + 1) != '\n' &&*(str + 1) != '\t')||(*str == '\0' && *(str + 1) != ' ' && *(str + 1) != '\0' && *(str + 1) != '\n' &&*(str + 1) != '\t')||(*str == '\0' && *(str + 1) != ' ' && *(str + 1) != '\0' && *(str + 1) != '\n' &&*(str + 1) != '\t'))
        {
            
            *(a + ct) = (str + 1);
            size_number ++;
            ct++;
            check_p_size ++;
            if(check_p_size == 29)
            {
                a = realloc(a,30 * sizeof(char*));
                check_p_size = 0;
            }
        }
        str ++;
        count ++;
    }
    if(only_space == 0)
    {
        free(a);
        *size = 0;
        return NULL;
    }
    *size = size_number;
    return a;
}
void printSubstrings(const char** sstrs, const int size) {
    if(sstrs == NULL)
    {
        return;
    }
    printf("{");
    for (int aa = 0; aa < size; aa++)
    {
        printf("%s",*(sstrs + aa));
        if(aa < size - 1)
        {
           printf(",");
        }
    }
    printf("}\n");
}
