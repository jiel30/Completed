#include "debug.h"
#include "protocol.h"
#include "queue.h"
#include "server.h"

#define USEAGE_STR "Server Application Usage: %s -p <port>\n"     \
                   "\t-p\tPort of server\n"

queue_t INBOX[256];
queue_t OUTBOX[256];
pthread_mutex_t locker;

int init_server(int server_port) {
    int sockfd;
    struct sockaddr_in servaddr;

    // socket create and verification
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        fatalp("socket\n");
    }

    info("Socket successfully created\n");

    bzero(&servaddr, sizeof(servaddr));

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(server_port);

    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, (char *)&opt, sizeof(opt)) < 0) {
        fatalp("setsockopt");
    }

    // Binding newly created socket to given IP and verification
    if ((bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr))) != 0) {
        fatalp("bind");
    } 
    info("Socket bind successful\n");

    // Now server is ready to listen and verification
    if ((listen(sockfd, 1)) != 0) {
        fatalp("listen");
    } 
    success("Server listening on port: %d.. Waiting for connection\n", server_port);

    return sockfd;
}

void* sorter(void* arg) {
    pthread_mutex_init(&locker,NULL);
    while(1)
    {
        pthread_mutex_lock(&locker);
        for(int aa = 0; aa < 256;aa++)
        {
            if(INBOX[aa].head != NULL)
            {
                info("Sorter moving pending messages from Client %d\n", aa);
                queue_node_t* nodes  = dequeue_all(&INBOX[aa]);
                while(nodes != NULL)
                {
                    pthread_mutex_lock(&OUTBOX[aa].mutex);
                    data_msg* data = nodes->data;
                    info("Sorter dropping message to Client %d\n", data->dest_id);
                    queue_node_t* rest = nodes->next;
                    nodes->next = NULL;
                    enqueue(&OUTBOX[data->dest_id],nodes);
                    nodes = rest;
                    pthread_mutex_unlock(&OUTBOX[aa].mutex);
                }
                
            }
        }
    }
    return NULL;
}

void* handle_deposit_client(void* arg) {
    data_msg* data;
    while((data = recv_data_msg((int)arg)) != NULL)
    {
        pthread_mutex_lock(&INBOX[data->src_id].mutex);
        info("Client %d deposited %s for Client %d!\n", data->src_id, data->msg, data->dest_id);
        queue_node_t* node = malloc(sizeof(queue_node_t));
        node->data = data;
        node->next = NULL;
        enqueue(&INBOX[data->src_id], node);
        pthread_mutex_unlock(&INBOX[data->src_id].mutex);
    }
    pthread_mutex_unlock(&locker);
    close((int)arg);
    return NULL;
}

void* handle_retrieve_client(void* arg) {
    int *numbers = (int*)arg;
    int id = numbers[1];
    info("Client %d wants to retrieve a message!\n", id);
    queue_node_t* nodes = dequeue_all(&OUTBOX[id]); 
    while(nodes != NULL) {
        pthread_mutex_lock(&OUTBOX[id].mutex);
        send_data_msg(numbers[0], nodes->data);
        free_data_msg(nodes->data);
        queue_node_t* ref = nodes;
        nodes = nodes->next;
        free(ref);
        pthread_mutex_unlock(&OUTBOX[id].mutex);
    }
    info("Sent all messages for Client %d!\n", id);
    close(numbers[0]);
    return NULL;
}

int main(int argc, char *argv[]) {
    int opt;
    unsigned int server_port = 0;
    while ((opt = getopt(argc, argv, "p:")) != -1) {
        switch (opt) {
        case 'p':
            server_port = atoi(optarg);
            break;
        default: /* '?' */
            fprintf(stderr, USEAGE_STR, argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    if (server_port == 0) {
        error("Server's port number to listen on is not given\n");
        fprintf(stderr, USEAGE_STR, argv[0]);
        exit(EXIT_FAILURE);
    }

    int sockfd = init_server(server_port);
    for (int i = 0; i < 256; i++) {
	    init_queue(&INBOX[i]);
	    init_queue(&OUTBOX[i]);
    }
    struct sockaddr_in client;
    pthread_t sort_id;
    pthread_create(&sort_id,NULL,sorter,NULL);
    while(1) {
        socklen_t client_len = sizeof(struct sockaddr_in);
        int clientfd = accept(sockfd, (struct sockaddr*)&client, &client_len);
        if (clientfd < 0) {
            fatalp("accept");
        }
        info("New connection! Socket %d\n", clientfd);
        /* 
         * Write code to figure out which type of client 
         * and start appropriate thread here.
         */
        connect_msg* message = recv_connect_msg(clientfd);
        int id = message->id;
        pthread_t sub_id;
        if(message -> type == DEPOSIT)
        {
            pthread_create(&sub_id,NULL,handle_deposit_client,(void*)clientfd);
        }
        else
        {
            int numbers[2];
            numbers[0] = clientfd;
            numbers[1] = id ;
            pthread_create(&sub_id,NULL,handle_retrieve_client,(void*)numbers);
        }
    }

    return 0;
}