#include "queue.h"

void init_queue(queue_t* q) {
    assert(q != NULL);
    q -> head = NULL;
    pthread_mutex_init(&q->mutex,NULL);
    pthread_mutex_unlock(&q->mutex);
}
