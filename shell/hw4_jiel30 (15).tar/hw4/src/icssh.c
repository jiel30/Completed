#include "icssh.h"
#include <readline/readline.h>
int flag = 0;

int c(void* a, void* b)
{
    node_t *x = (node_t*)a;
    node_t *y = (node_t*)b;
    bgentry_t* v1 = (bgentry_t*)(x -> value);
    bgentry_t* v2 = (bgentry_t*)(y -> value);
    if(v1 -> seconds < v2 -> seconds)
    {
        return 0;
    }
    return 1;
}
void handler(int sig)
{
    flag = 1;
}

void clean_bg(List_t* l)
{
    node_t* current = l -> head;
    
}
int main(int argc, char* argv[]) {
	int exec_result;
	int exit_status;
	pid_t pid;
	pid_t wait_result;
	char* line;
#ifndef DEBUG
	rl_outstream = fopen("/dev/null", "w");
#endif
	// Setup segmentation fault handler
	if (signal(SIGSEGV, sigsegv_handler) == SIG_ERR) {
		perror("Failed to set signal handler");
		exit(EXIT_FAILURE);
	}
    List_t *l = (List_t*)malloc(sizeof(List_t));
    l -> comparator = c;
    l-> head = NULL;
    l -> length = 0;
    // print the prompt & wait for the user to enter commands string
	while ((line = readline(SHELL_PROMPT)) != NULL) {
        // MAGIC HAPPENS! Command string is parsed into a job struct
        // Will print out error message if command string is invalid
        job_info* job = validate_input(line);
        signal(SIGCHLD, handler);
        if(flag == 1)
        {
            flag = 0;
            pid_t p = 10;
            while(p > 0)
            {
                p = waitpid(-1,&exit_status,WNOHANG);
                if (p <= 0)
                {
                    break;
                }
                node_t* current = l -> head;
                node_t* prev = current;
                int index = 0;
                while(1)
                {
                    if (((bgentry_t*)(current -> value))->pid == p)
                    {
                        break;
                    }
                    prev = current;
                    current = current -> next;
                    index ++;
                }
                bgentry_t* bt = (bgentry_t*)(current->value);
                kill(bt->pid,SIGKILL);
                printf(BG_TERM,p,bt -> job -> line);
                if(index == 0)
                {
                    l-> head = current -> next;
                }
                else
                {
                    prev -> next = current -> next;
                    free(current);
                }
            }
        }
        if(strcmp(job->procs->cmd, "bglist") == 0)
        {
//                 printf("enter bglist\n");
            node_t* current = l->head;
//             dup2(1,2);
            while(current != NULL)
            {
                bgentry_t* p = (bgentry_t*)(current->value);
                print_bgentry(p);
                current = current -> next;
            }
//             dup2(2,1);
            continue;
        }
        if (job == NULL) { // Command was empty string or invalid
			free(line);
			continue;
		}

        //Prints out the job linked list struture for debugging
        debug_print_job(job);

		// example built-in: exit
		if (strcmp(job->procs->cmd, "exit") == 0) {
			// Terminating the shell
            node_t* current = l -> head;
            while(current != NULL)
            {
                bgentry_t* bt = (bgentry_t*)(current->value);
                kill(bt->pid,SIGKILL);
                current = current -> next;
            }
            deleteList(l);
			free(line);
			free_job(job);
			return 0;
		}
		// example of good error handling!
        pid = fork();
		if (pid < 0) {
			perror("fork error");
			exit(EXIT_FAILURE);
		}
        proc_info* now = job -> procs;
        proc_info* proc = now;
        int df[2];
        int* read_part;
        int* write_part;
        int childpid;
        int access = 0;
        if(job -> bg == 1)
        {
            access = 1;
        }
		if (pid == 0) {  //If zero, then it's the child process
    //get the first command in the job list
            while (now->next_proc != NULL)
            {
                proc = now;
                pipe(df);
                read_part = &df[0];
                write_part = &df[1];
                pid = fork();
                if(pid != 0)
                {
                    //this is parent process
                    close(*read_part);
                    dup2(*write_part,1);
                    break;
                }
                else
                {
//                     char* bug = (char*)malloc(100);
                    access = 0;
                    close(*write_part);
                    dup2(*read_part,0);
                    now = now -> next_proc;
                    if(now -> next_proc == NULL)
                    {
                        proc = now;
                        break;
                    }
                }
            }
            int fd;
            if((proc -> in_file == proc -> out_file&& proc -> in_file != NULL)|| (proc -> in_file == proc -> err_file&& proc -> in_file != NULL) || (proc -> out_file == proc -> err_file &&proc -> out_file != NULL))
            {
                fprintf(stderr,RD_ERR);
            }
            else
            {
                if(proc -> in_file != NULL)
                {
                    fd = open(proc->in_file, O_RDONLY);
                    if(fd != -1)
                    {
                        dup2(fd,0);
                        close(fd);
                    }
                    else
                    {
                        fprintf(stderr,RD_ERR);
                        continue;
                    }
                }
                if(proc -> out_file != NULL)
                {
                    fd = open(proc->out_file, O_RDWR|O_CREAT);
                    if(fd != 1)
                    {
                        dup2(fd,1);
                        close(fd);
                    }
                    else
                    {
                        fprintf(stderr,RD_ERR);
                        continue;
                    }
                }
                if(proc -> err_file != NULL)
                {
                    fd = open(proc->err_file, O_RDWR|O_CREAT);
                    if(fd != -1)
                    {
                        dup2(fd,2);
                        close(fd);
                    }
                    else
                    {
                        fprintf(stderr,RD_ERR);
                        continue;
                    }
                }
            }
            if(strcmp(job->procs->cmd, "cd") == 0||strcmp(job->procs->cmd, "estatus") == 0||strcmp(job->procs->cmd, "bglist") == 0)
            {
                exec_result = 0;
            }
            else
            {
                exec_result = execvp(proc->cmd, proc->argv);
            }
			if (exec_result < 0) {  //Error checking
				printf(EXEC_ERR, proc->cmd);
				exit(EXIT_FAILURE);
			}
			exit(EXIT_SUCCESS);
		} 
        if((pid != 0 && proc->next_proc == NULL) || (job->bg == 1&&pid != 0 && access == 1)) 
        {
//             signal(SIGCHLD, handler);
//             if(flag == 1)
//             {
//                 flag = 0;
//                 pid_t p = 10;
//                 while(p > 0)
//                 {
//                     p = waitpid(-1,&exit_status,WNOHANG);
//                     if (p <= 0)
//                     {
//                         break;
//                     }
//                     node_t* current = l -> head;
//                     node_t* prev = current;
//                     int index = 0;
//                     while(1)
//                     {
//                         if (((bgentry_t*)(current -> value))->pid == p)
//                         {
//                             break;
//                         }
//                         prev = current;
//                         current = current -> next;
//                         index ++;
//                     }
//                     bgentry_t* bt = (bgentry_t*)(current->value);
//                     kill(bt->pid,SIGKILL);
//                     printf(BG_TERM,p,bt -> job -> line);
//                     if(index == 0)
//                     {
//                         l-> head = current -> next;
//                     }
//                     else
//                     {
//                         prev -> next = current -> next;
//                         free(current);
//                     }
//                 }
//             }
//             printf("finish handle signal\n");
            // As the parent, wait for the foreground job to finish
            proc_info* proc = job->procs;
            if(strcmp(job->procs->cmd, "cd") == 0)
            {
                int result = 0;
                if(proc->argc == 0)
                {
                    result = chdir(getenv("HOME"));
                }
                else
                {
                    result = chdir((proc -> argv)[1]);
                }
                if(result == 0)
                {
                    printf("%s\n",getcwd(NULL,0));
                }
                if (result == -1)
                {
                    fprintf(stderr,DIR_ERR);
                }
            }
//             if(strcmp(job->procs->cmd, "bglist") == 0)
//             {
// //                 printf("enter bglist\n");
//                 node_t* current = l->head;
//                 while(current != NULL)
//                 {
//                     bgentry_t* p = (bgentry_t*)(current->value);
//                     print_bgentry(p);
//                     current = current -> next;
//                 }
//             }
            if(strcmp(job->procs->cmd, "estatus") == 0)
            {
                printf("%d\n",WEXITSTATUS(exit_status));
            }
//             printf("finish execute\n");
            if(job -> bg == 1)
            {
                bgentry_t * bg = (bgentry_t*)malloc(sizeof(bgentry_t));
                bg -> job = job;
                bg -> pid = pid;
                bg -> seconds = time(NULL);
                node_t * temp = (node_t*)malloc(sizeof(node_t));
                temp-> next = NULL;
                temp -> value = (void*)bg;
                node_t* c = l->head;
                node_t* before = c;
                if(c == NULL)
                {
                    l -> head = temp;
                }
                else
                {
                    while (c != NULL)
                    {
                        before = c;
                        c = c -> next;
                    }
                    before -> next = temp;
                }
                continue;
            }
//             printf("finish set bg\n");
			wait_result = waitpid(pid, &exit_status, 0);
//             printf("finish waiting\n");
			if (wait_result < 0) {
				printf(WAIT_ERR);
				exit(EXIT_FAILURE);
			}
		}
        if((pid != 0 && proc->next_proc != NULL))
        {
            wait_result = waitpid(pid, &exit_status, 0);
            if (wait_result < 0) {
				printf(WAIT_ERR);
				exit(EXIT_FAILURE);
            }
        }
        
		free_job(job);  // if a foreground job, we no longer need the data
		free(line);
	}
#ifndef DEBUG
	fclose(rl_outstream);
#endif
	return 0;
}
