// Your helper functions need to be here.
