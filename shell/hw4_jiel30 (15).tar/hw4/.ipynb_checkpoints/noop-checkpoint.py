import time
time.sleep(10)
print("finish waiting 10 seconds")