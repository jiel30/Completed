import sys

if __name__ == '__main__':
    i = 0
    for arg in sys.argv:
        print(i,':',arg)