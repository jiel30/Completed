/**
 * Do not submit your assignment with a main function in this file.
 * If you submit with a main function in this file, you will get a zero.
 * If you want to make helper functions, put them in helpers.c
 */
#include "icsmm.h"
#include "helpers.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include<string.h>

ics_header *prologue = NULL;
ics_header *epilogue = NULL;
ics_free_header *freelist_head = NULL;

void copy(void* a, void* b, int number)
{
    for(int aa = 0; aa < number; aa++)
    {
        *((char*)a + aa) = *((char*)b + aa);
    }
}

void insert(ics_free_header *f)
{
    if(freelist_head == NULL)
    {
        freelist_head = f;
        f->prev = NULL;
        f -> next = NULL;
        return;
    }
//     printf("start to insert\n");
    ics_free_header* current = freelist_head;
    ics_free_header* p = current;
    int inserted = 0;
    while(current != NULL)
    {
        if((void*)current > (void*)f)
        {
//             printf("current: %p\n",(void*)current);
//             printf("p: %p\n",(void*)p);
//             printf("self: %p\n",(void*)f);
            if(current == freelist_head)
            {
                f->prev = NULL;
                f -> next = current;
                current -> prev = f;
                freelist_head = f;
//                 printf("done assign here\n");
            }
            else
            {
                p -> next = f;
                f -> prev = p;
                f -> next = current;
                current -> prev = f;
//                 printf("done assign\n");
            }
            inserted = 1;
//             printf("after --> current: %p\n",(void*)current);
//             printf("after --> p: %p\n",(void*)p);
//             printf("prev of current: %p\n",(void*)(current -> prev));
//             printf("next of p: %p\n",(void*)(p -> next));
            break;
        }
        p = current;
        current = current -> next;
    }
    if(inserted == 0)
    {
        p->next = f;
        f -> next = NULL;
        f->prev = p;
//         printf("next of p: %p\n",(void*)(p -> next));
//         printf("self: %p\n",(void*)f);
    }
//     printf("finish insert\n");
}
void coalesce(ics_free_header* free_one)
{
//     printf("start to coalesce\n");
    int merge_front = 0;
    int merge_rear = 0;
    ics_footer *f = (ics_footer*)((char*)free_one - 8);
    if((void*)f > (void*)prologue)
    {
        if((f->block_size)%2 == 0)
        {
            merge_front = 1;
            ics_free_header *temp_header = (ics_free_header*)((char*)f - (f->block_size - 8));
            temp_header ->header.block_size = (temp_header->header.block_size) + (free_one ->header.block_size);
            ics_footer *back_footer = (ics_footer*)((char*)free_one + (free_one ->header.block_size - 8));
            back_footer -> block_size = temp_header ->header.block_size;
            back_footer->unused = 0x333333333333;
            back_footer ->padding_amount = 0;
            free_one = temp_header;
            free_one ->header.unused = 0x1999999999999;
        }
//         printf("finish coalescing the front one\n");
    }
    ics_free_header * back_header = (ics_free_header*)((char*)free_one + (free_one ->header.block_size));
    if((void*)back_header < (void*)epilogue)
    {
        if((back_header->header.block_size)%2 == 0)
        {
            merge_rear = 1;
            free_one ->header.block_size = free_one->header.block_size + back_header ->header.block_size;
            ics_footer* temp_f = (ics_footer*)((char*)free_one + (free_one->header.block_size - 8));
            temp_f -> unused = 0x333333333333;
            temp_f -> block_size = free_one->header.block_size;
            temp_f->padding_amount = 0;
        }
//         printf("finish coalscing the back\n");
    }
    ics_free_header *current = freelist_head;
    while(current != NULL)
    {
        if((void*)current == (void*)free_one)
        {
            if(merge_rear == 1 && merge_front == 1)
            {
                free_one -> next = current -> next -> next -> next;
                if(current -> next != NULL)
                {
                    current -> next -> prev = free_one;
                }
            }
            else if(merge_rear == 1 || merge_front == 1)
            {
                free_one -> next = current -> next -> next;
                if(current -> next != NULL)
                {
                    current -> next -> prev = free_one;
                }
            }
            current = free_one;
            break;
        }
        current = current -> next;
    }
//     printf("end of co\n");
}

void *ics_malloc(size_t size)
{
    if(size <= 0)
    {
        errno = EINVAL;
        return NULL;
    }
    if(prologue == NULL)
    {
        prologue = (ics_header*) ics_inc_brk();
        prologue-> unused = 0x1999999999999;
        prologue-> block_size = 8;
        epilogue = (ics_header*)((char*)prologue + 4088);
        epilogue -> unused = 0x1999999999999;
        epilogue-> block_size = 8;
        freelist_head = (ics_free_header*)(prologue + 1);
        freelist_head -> header.unused = 0x1999999999999;
        freelist_head->header.block_size = 4080;
        freelist_head -> prev = NULL;
        freelist_head -> next = NULL;
        ics_footer *footer = (ics_footer*)(epilogue - 1);
        footer -> block_size = 4080;
        footer -> unused = 0x333333333333;
        footer->padding_amount = 0;
    }
    int pad_number = 0;
    if(size % 16 != 0)
    {
        pad_number = 16 - (size%16);
    }
    ics_free_header *current = freelist_head;
//     ics_free_header * find_last = current;
    int check = 0;
    while(current != NULL)
    {
        if((current -> header).block_size >= (size + pad_number + 16))
        {
//             printf("block_size: %d\n",(current -> header).block_size);
//             printf("total size needed: %ld\n",(size + pad_number + 16));
//             printf("size: %ld \t enter while\n",size);
            int block_value = (int)(current->header.block_size);
            ics_free_header * n = current->next;
            ics_header *newone = (ics_header*)current;
//             printf("finish init\n");
            if(check == 0)
            {
//                 printf("get in check == 0\n");
                if((freelist_head -> header).block_size -32 < (size + pad_number + 16))
                {
                    pad_number = (freelist_head -> header).block_size - (size + 16);
                    if(freelist_head -> next == NULL)
                    {
                        freelist_head = NULL;
                    }
                    else
                    {
                        freelist_head = freelist_head -> next;
                        freelist_head ->prev = NULL;
                    }
                }
                else
                {
                    freelist_head = (ics_free_header*)((char*)freelist_head + (size + pad_number + 16));
                    freelist_head -> header.block_size = block_value - (size + pad_number + 16);
                    freelist_head -> header.unused = 0x1999999999999; 
                    freelist_head -> prev = NULL;
                    freelist_head -> next = n;
                    ics_footer * foo = (ics_footer*)((char*)freelist_head + ((freelist_head->header).block_size - 8));
                    foo -> block_size = block_value - (size + pad_number + 16);
                    foo->unused = 0x333333333333;
                    foo->padding_amount = 0;
                    
                }
//                 printf("size: %ld \t finish if\n",size);
            }
            else
            {
                if(current -> header.block_size - 32 >= (size + pad_number + 16))
                {
                    ics_free_header *pre = current -> prev;
                    ics_free_header *next = current -> next;
                    ics_free_header *now = (ics_free_header*)((char*)current + (size + pad_number + 16));
                    now -> header.block_size = block_value - (size + pad_number + 16);
                    now -> header.unused = 0x1999999999999;
                    now -> next = next;
                    now -> prev = pre;
                    pre->next = now;
                    if(next != NULL)
                    {
                        next -> prev = now;
                    }
                    ics_footer *now_footer = (ics_footer*)((char*)now + ((now->header).block_size-8));
                    now_footer->block_size = block_value - (size + pad_number + 16);
                    now_footer->unused = 0x333333333333;
                    now_footer->padding_amount = 0;
                }
                else
                {
                    pad_number = block_value - (size + 16);
                    ics_free_header *pre = current -> prev;
                    ics_free_header *next = current -> next;
                    pre -> next = next;
                    if(next != NULL)
                    {
                        next -> prev = pre;
                    }
                }
//                 printf("size: %ld \t finish else\n",size);
            }
            int check_pad = 0;
            if(pad_number != 0)
            {
                check_pad = 2;
            }
            newone -> block_size = (size + pad_number + 16) + check_pad + 1;
//             printf("the block size of newone : %d\n",newone->block_size);
            newone -> unused = 0x1999999999999;
            void* payload = newone + 1;
            ics_footer * footer = (ics_footer*)((char*)newone + (size + pad_number + 8));
//             printf("block size of footer: %d\n",footer->block_size);
            footer->block_size = (size + pad_number + 16) + check_pad + 1;
//             printf("block size of footer after: %d\n",footer->block_size);
            footer -> unused = 0x333333333333;
            footer -> padding_amount = pad_number;
            return payload;
        }
        check ++;
//         find_last = current;
        current = current -> next;
    }
    //now we can assume that we do not have enough space in heap
//     printf("after return\n");
//     printf("size %ld is too large to fit\n",size);
    ics_inc_brk();
    if(errno == ENOMEM)
    {
        return NULL;
    }
    ics_footer *check_footer = (ics_footer*)((char*)epilogue - 8);
    epilogue = (ics_header*)((char*)epilogue + 4096);
    epilogue -> unused = 0x1999999999999;
    epilogue-> block_size = 8;
    ics_free_header *new_last = (ics_free_header*)((char*)check_footer + 8);
    if(check_footer->block_size %2 == 0)
    {
        ics_free_header *check_header = (ics_free_header*)((char*)check_footer - (check_footer->block_size-8));
        check_header -> header.block_size = check_header -> header.block_size + 4096;
        ics_footer *new_footer = (ics_footer*)((char*)epilogue - 8);
        new_footer->block_size = check_header->header.block_size;
        new_footer->unused = 0x333333333333;
        new_footer->padding_amount = 0;
    }
    else
    {
//         new_last -> prev = find_last;
//         new_last -> next = NULL;
//         find_last -> next = new_last;
        (new_last->header).block_size= 4096;
        (new_last->header).unused = 0x1999999999999;
        insert(new_last);
        ics_footer *new_footer = (ics_footer*)((char*)epilogue - 8);
        new_footer->block_size = 4096;
        new_footer->unused = 0x333333333333;
        new_footer->padding_amount = 0;
    }
    return ics_malloc(size);
}

void *ics_realloc(void *ptr, size_t size)
{
    if (size == 0)
    {
        ics_free(ptr);
        return NULL;
    }
    ics_header *header = (ics_header*)((char*)ptr - 8);
    int pad_number = 0;
    if(size % 16 != 0)
    {
        pad_number = 16 - (size%16);
    }
    int pad = 0;
    if((header -> block_size - 1)%16 != 0)
    {
        pad = 2;
    }
    ics_footer *footer = (ics_footer*)((char*)header + (header->block_size -9 - pad));
    if((void*)footer == (void*)header)
    {
//         printf("header error\n");
        return NULL;
    }
    if(ptr > (void*)epilogue || ptr < (void*)prologue)
    {
//         printf("epi and pro error\n");
        errno = EINVAL;
        return NULL;
    }
    if(header->unused != 0x1999999999999)
    {
//         printf("0x999 error\n");
        errno = EINVAL;
        return NULL;
    }
    if(footer->unused != 0x333333333333 || footer->block_size != header->block_size)
    {
//         printf("0x333 or footer, header block_size error\n");
//         printf("header: %d\t footer: %d\n",header->block_size, footer -> block_size);
        errno = EINVAL;
        return NULL;
    }
    if((footer->block_size)%2 != 1 ||(header->block_size)%2 != 1)
    {
//         printf("2 != 1 error\n");
       errno = EINVAL;
       return NULL; 
    }
    int s = header -> block_size;
    size = size + pad_number + 16;
    if(s == size)
    {
        return NULL;
    }
    if(s > size)
    {
        ics_footer *new_footer = (ics_footer*)((char*)header + (size - 8));
        new_footer -> block_size = size;
        new_footer -> unused = 0x333333333333;
        new_footer -> padding_amount = pad_number;
        header ->block_size = size;
        void* payload = (void*)((char*)header + 8);
        return payload;
    }
    else
    {
        ics_footer *new_footer = (ics_footer*)((char*)header + (size - 8));
        if(new_footer == ptr);
        void* a = ics_malloc((size - pad_number - 16));
        void* payload = (void*)((char*)a + 8);
//         memcpy(payload,ptr,(header->block_size -9 - pad));
        copy(payload,ptr,(header->block_size -9 - pad));
        ics_free(ptr);
        return payload;
    }
    return NULL;
    
}

int ics_free(void *ptr)
{
    ics_header* header = (ics_header*)((char*)ptr - 8 );
    int p = 0;
    if((header->block_size - 1)%16 != 0)
    {
        p = 2;
    }
    ics_footer* footer = (ics_footer*)((char*)header + (header->block_size - 8 - 1 - p));
    if((void*)footer == (void*)header)
    {
//         printf("header error\n");
        return 0;
    }
    if(ptr > (void*)epilogue || ptr < (void*)prologue)
    {
//         printf("epi and pro error\n");
        errno = EINVAL;
        return -1;
    }
    if(header->unused != 0x1999999999999)
    {
//         printf("0x999 error\n");
        errno = EINVAL;
        return -1;
    }
    if(footer->unused != 0x333333333333 || footer->block_size != header->block_size)
    {
//         printf("0x333 or footer, header block_size error\n");
//         printf("header: %d\t footer: %d\n",header->block_size, footer -> block_size);
        errno = EINVAL;
        return -1;
    }
    if((footer->block_size)%2 != 1 ||(header->block_size)%2 != 1)
    {
//         printf("2 != 1 error\n");
       errno = EINVAL;
       return -1; 
    }
    int size = (int)(header->block_size);
    int pad_number = 0;
    if((size - 1)%16 != 0)
    {
        pad_number = 2;
    }
    ics_free_header *new_free = (ics_free_header*)header;
    new_free->header.block_size = size -1 - pad_number;
    new_free -> header.unused = 0x1999999999999;
    footer->block_size = new_free->header.block_size;
    insert(new_free);
    coalesce(new_free);
    return 0;
}
