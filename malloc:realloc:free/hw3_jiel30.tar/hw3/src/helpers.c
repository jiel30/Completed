#include "helpers.h"

/* Helper function definitions go here */
// void coalesce(ics_header* free_one)
// {
//     ics_footer *f = (ics_footer*)free_one - 1;
//     if(f > prologue)
//     {
//         if((f->block_size)%2 == 0)
//         {
//             ics_header *temp_header = f - (f->block_size - 64)/8;
//             temp_header -> block_size = temp_header->block_size + free_one -> block_size;
//             ics_footer *back_footer = free_one + (free_one -> block_size)/8 - 1;
//             back_footer -> block_size = temp_header -> block_size;
//             free_one = temp_header;
//         }
//     }
//     ics_footer * back_header = free_one + (free_one -> block_size)/8;
//     if(back_header < epilogue)
//     {
//         if((back_header->block_size)%2 == 0)
//         {
//             free_one -> block_size = free_one->block_size + back_header -> block_size;
//             footer* temp_f = free_one + (free_one->block_size - 64)/8;
//             temp_f -> block_size = free_one-> bock_size;
//         }
//     }
//     ics_free_header *current = freelist_head;
//     while(current != NULL)
//     {
//         if(current == free_one)
//         {
//             current -> header = *free_one;
//         }
//     }
// }